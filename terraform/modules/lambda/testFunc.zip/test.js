modules.exports.testFunc = () => {
	console.log("Running test function");
}
